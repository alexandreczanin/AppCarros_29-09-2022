﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace AppCarros
{
    class Contrato
    {
        public int ID { get; set; }
        public DateTime Início { get; set; }
        public DateTime Fim { get; set; }
        public int Cliente { get; set; }
        public int Funcionário { get; set; }
        public int Preço { get; set; }

        public List<Contrato> listacontrato()
        {
            List<Contrato> li = new List<Contrato>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand(); ;
            cmd.CommandText = "SELECT * FROM Contrato";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Contrato u = new Contrato();
                u.ID = (int)dr["Id"];
                u.Início = Convert.ToDateTime(dr["datainicial"]);
                u.Fim = Convert.ToDateTime(dr["datafinal"]);
                u.Cliente = (int)dr["clienteid"];
                u.Funcionário = (int)dr["funcionarioid"];
                u.Preço = (int)dr["preco"];
                li.Add(u);
            }
            return li;
        }
    }

    public class clientecontrato
    {
        public int Id { get; set; }
        public string nome { get; set; }
        public string cpf { get; set; }
        public string celular { get; set; }

        public void LocalizarNomeCliente(string nome)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Cliente WHERE nome='" + nome + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Id = (int)dr["id"];
                nome = dr["nome"].ToString();
                cpf = dr["cpf"].ToString();
                celular = dr["celular"].ToString();
            }
        }

        public void LocalizarIdCliente(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Select * FROM Cliente where Id ='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                cpf = dr["cpf"].ToString();
                celular = dr["celular"].ToString();
            }
        }
    }

    public class funcionariocontrato
    {

        public int Id { get; set; }
        public string nome { get; set; }
        public string celular { get; set; }
        public string cpf { get; set; }
        public void LocalizarIdFuncionario(int id)
        {

            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM funcionario WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                nome = dr["nome"].ToString();
                cpf = dr["cpf"].ToString();
                celular = dr["celular"].ToString();
            }
        }

        public void LocalizarNOmeFUncionario(string nome)
        {
            SqlConnection con2 = ClassConecta.ObterConexao();
            SqlCommand cmd2 = con2.CreateCommand();
            cmd2.CommandText = "SELECT * FROM funcionario WHERE nome='" + nome + "'";
            cmd2.CommandType = CommandType.Text;
            SqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                Id = (int)dr2["id"];
                cpf = dr2["cpf"].ToString();
                celular = dr2["celular"].ToString();
            }
        }
    }

    public class carrocontrato
    {
        public int id { get; set; }
        public string marca { get; set; }
        public string modelo { get; set; }

        public void LocalizarCarro(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Select * From Carro where Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                marca = dr["marca"].ToString();
                modelo = dr["modelo"].ToString();
            }
        }
    }

    public class contrato
    {
        public int Id { get; set; }
        public DateTime datainicial { get; set; }
        public DateTime datafinal { get; set; }
        public int clienteid { get; set; }
        public int funcionarioid { get; set; }
        public int preco { get; set; }
        public int carroid { get; set; }

        public void CadastrarContrato(DateTime datainicial, DateTime datafinal, int clienteid, int funcionarioid, int preco, int carroid)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Insert into Contrato (datainicial,datafinal,clienteid,funcionarioid,preco,carroid) values (Convert(DateTime,'" + datainicial + "',103),Convert(DateTime,'" + datafinal + "',103),'" + clienteid + "','" + funcionarioid + "','" + preco + "','" + carroid + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void deletarcontrato(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Delete from Contrato where Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void localizarconrato(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "Select * From Contrato where Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                datainicial = Convert.ToDateTime(dr["datainicial"]);
                datafinal = Convert.ToDateTime(dr["datafinal"]);
                clienteid = (int)dr["clienteid"];
                funcionarioid = (int)dr["funcionarioid"];
                preco = (int)dr["preco"];
                carroid = (int)dr["carroid"];
            }
        }
    }
}
